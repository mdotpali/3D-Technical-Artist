black = (0, 0, 0)
white = (1, 1, 1)
red = (1, 0.25, 0.25)
green = (0.25, 1, 0.25)
blue = (0.2, 0.6, 1)
yellow = (1, 0.9, 0.2)
normal = (0.5, 0.5, 1)

light_blue = (0.4, 0.7, 1)
